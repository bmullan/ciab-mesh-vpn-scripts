#!/bin/bash

sudo wg-quick down ciabmesh

